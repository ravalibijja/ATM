# ATM

Description: This project was to make an automated teller machine with user's account and password, bank account, with that user are able to withdraw, deposit, and view their account balance.

Predefined account and password:

Account #: 123456789 Password #: 1234

Account #: 123456789 Password #: 1230
